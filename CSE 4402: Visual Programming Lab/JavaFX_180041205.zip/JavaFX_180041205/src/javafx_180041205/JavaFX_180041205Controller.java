/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafx_180041205;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class.
 * All the attributes and behaviors of the constituent components of the UI are written in this class.
 * @author Nobel
 */
public class JavaFX_180041205Controller implements Initializable {

    @FXML
    private TextField theTextArea;
    @FXML
    private Button theExitButton;
    @FXML
    private Label theGreeting;
    @FXML
    private Button theSubmitButton;
    String name="";

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    /**
     * This function dictates the sequence of actions that needs to be done when the "Exit" button is clicked.
     * The button is placed in a Scene, which is on a Stage and that Stage is also known as the Window. Our target is to close the Window.
     * So, using the 1st line of the function, we return the Stage of the button. Then, using the close() function, we simply close the window.
     * @param event  An Event representing some type of action. In this case, when the "Exit" button is triggered.
    */
    @FXML
    private void handleExitButton(ActionEvent event) {
        Stage stage=(Stage)theExitButton.getScene().getWindow();
        stage.close();
    }
    /**
     * This function dictates the sequence of actions that needs to be done when the "Submit" button is clicked.
     * After being triggered, the text written in the Text Area will be scanned and assigned to the String member variable name.
     * Then, a setText() function will be used to display the string that greets the name given by the user in theGreeting label. 
     * @param event  An Event representing some type of action. In this case, when the "Submit" button is triggered.
     */
    @FXML
    private void handleSubmitButton(ActionEvent event) {
        name=theTextArea.getText();
        //System.out.println(name);
        theGreeting.setText("Greetings, "+name+". Have a nice day! 🙂");
    }
    
}
