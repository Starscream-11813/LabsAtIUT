/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafx_180041205;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
/**
 *This is the .java class that holds the main() function which is responsible for launching the UI.
 * @author Rifat
 */
public class JavaFX_180041205 extends Application
{
    /**
     * The start() method is the main entry point of all the JavaFX applications.
     * The UI container is defined by means of a Stage and a Scene and it is done in the overridden version of the start() function.
     * @param stage The top-level JavaFX container, that is, the Window itself.
     * @throws Exception 
     */
    @Override
    public void start(Stage stage) throws Exception 
    {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        Parent root;
        root = FXMLLoader.load(getClass().getResource("JavaFX_180041205.fxml"));
        Scene scene=new Scene(root);
        stage.setTitle("Greet Yourself!");
        stage.setScene(scene);
        stage.show();
    }
    /**
     * Launches the JavaFX application using the static method launch().
     * @param args Arguments of the main function
     */
    public static void main(String[] args)
    {
        launch(args);
    }
}
