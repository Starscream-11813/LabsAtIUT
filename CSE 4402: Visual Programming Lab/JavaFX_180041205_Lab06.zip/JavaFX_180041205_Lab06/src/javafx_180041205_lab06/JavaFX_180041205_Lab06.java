/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafx_180041205_lab06;

import java.lang.ModuleLayer.Controller;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Rifat
 */
public class JavaFX_180041205_Lab06 extends Application
{
    //Controller controller;
    //Stage mainStage;
    @Override
    public void start(Stage stage) throws Exception 
    {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        Parent root;
        //FXMLLoader loader=new FXMLLoader();
        root = FXMLLoader.load(getClass().getResource("JavaFXML_180041205.fxml"));
        //controller=loader.getController();
        Scene scene=new Scene(root);
        //mainStage=stage;
        stage.setTitle("Reminisce The International 2015");
        stage.setScene(scene);
        stage.show();
    }
    public static void main(String[] args) 
    {
        launch(args);
    }
}
