/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafx_180041205_lab06;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Rifat
 */
public class JavaFXML_180041205Controller implements Initializable {

    @FXML
    private Button theExitButton;
    @FXML
    private Button theNextPageButton;
    @FXML
    private Label theHomePageLabel;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleExitButton(ActionEvent event) throws IOException 
    {
        Parent exitConfirmationPageParent=FXMLLoader.load(getClass().getResource("JavaFXML_180041205_ExitConfirm.fxml"));
        Scene exitConfirmationPageScene=new Scene(exitConfirmationPageParent);
        //Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
        Stage window=new Stage();
        window.setScene(exitConfirmationPageScene);
        window.setTitle("Exit Confirmation");
        window.show();
    }

    @FXML
    private void handleNextPageButton(ActionEvent event) throws IOException 
    {
        Parent page02Parent=FXMLLoader.load(getClass().getResource("JavaFXML_180041205_Page02.fxml"));
        Scene page02Scene=new Scene(page02Parent);
        Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(page02Scene);
        window.show();
    }
    
}
